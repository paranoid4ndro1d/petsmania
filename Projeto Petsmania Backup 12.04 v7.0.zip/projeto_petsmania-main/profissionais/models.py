from datetime import date
from django.db import models
from django.conf import settings
from django.core.validators import RegexValidator
from django.core.exceptions import ValidationError
from django.db.models.fields.related import ForeignKey

class Especialidade(models.Model):
    nome = models.CharField(verbose_name="Nome", max_length=200)
    
    def __str__(self):
        return f'{self.nome}'
    
class Profissional(models.Model):
    nome = models.CharField(verbose_name="Nome", max_length=200)
    email = models.EmailField(verbose_name="Email")
    phone_regex = RegexValidator(
    regex=r'^\+?1?\d{9,15}$',
    message="O número precisa estar neste formato: \
                    '+99 99 9999-0000'.")

    telefone = models.CharField(verbose_name="Telefone",
                                validators=[phone_regex],
                                max_length=17, null=True, blank=True)
    especialidade = ForeignKey(Especialidade,
                               on_delete=models.CASCADE,
                               related_name='profissionais')
    
    def __str__(self):
        return f'{self.nome}'

def validar_dia(value):
    today = date.today()
    weekday = date.fromisoformat(f'{value}').weekday()

    if value < today:
        raise ValidationError('Não é possivel escolher um data atrasada.')
    if (weekday == 5) or (weekday == 6):
        raise ValidationError('Escolha um dia útil da semana.')

class Agenda(models.Model):
    profissional = ForeignKey(Profissional, on_delete=models.CASCADE, related_name='agenda')
    dia = models.DateField(help_text="Insira uma data para agenda", validators=[validar_dia])
    
    HORARIOS = (
        ("1", "07:00 às 08:00 - Veterinário(a)"),
        ("2", "07:00 às 08:00 - Banhista"),
        ("3", "07:00 às 08:00 - Tosador(a)"),
        ("4", "07:00 às 08:00 - Tosador(a)"),
        ("5", "07:00 às 08:00 - Cuidador(a)"),
        ("6", "07:00 às 08:00 - Banhista"),
        ("7", "08:00 às 09:00 - Veterinário(a)"),
        ("8", "08:00 às 09:00 - Banhista"),
        ("9", "08:00 às 09:00 - Tosador(a)"),
        ("10", "08:00 às 09:00 - Tosador(a)"),
        ("11", "08:00 às 09:00 - Cuidador(a)"),
        ("12", "08:00 às 09:00 - Banhista"),
        ("13", "09:00 às 10:00 - Veterinário(a)"),
        ("14", "09:00 às 10:00 - Banhista"),
        ("15", "09:00 às 10:00 - Tosador(a)"),
        ("16", "09:00 às 10:00 - Tosador(a)"),
        ("17", "09:00 às 10:00 - Cuidador(a)"),
        ("18", "09:00 às 10:00 - Banhista"),
        ("19", "10:00 às 11:00 - Veterinário(a)"),
        ("20", "10:00 às 11:00 - Banhista"),
        ("21", "10:00 às 11:00 - Tosador(a)"),
        ("22", "10:00 às 11:00 - Tosador(a)"),
        ("23", "10:00 às 11:00 - Cuidador(a)"),
        ("24", "10:00 às 11:00 - Banhista"),
        ("25", "11:00 às 12:00 - Veterinário(a)"),
        ("26", "11:00 às 12:00 - Banhista"),
        ("27", "11:00 às 12:00 - Tosador(a)"),
        ("28", "11:00 às 12:00 - Tosador(a)"),
        ("29", "11:00 às 12:00 - Cuidador(a)"),
        ("30", "11:00 às 12:00 - Banhista"),
    )
    horario = models.CharField(max_length=10, choices=HORARIOS)
    
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, 
        verbose_name='Usuário', 
        on_delete=models.CASCADE
    )
    class Meta:
        unique_together = ('horario', 'dia')
        
    def __str__(self):
        return f'{self.dia.strftime("%b %d %Y")} - {self.get_horario_display()} - {self.profissional}'