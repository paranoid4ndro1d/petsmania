from django.contrib import admin

from profissionais.models import Especialidade, Profissional, Agenda

class EspecialidadeAdmin(admin.ModelAdmin):
    list_display = ['nome']
    
class ProfissionalAdmin(admin.ModelAdmin):
    list_display = [
        'nome', 'telefone',
    ]
    
class AgendaAdmin(admin.ModelAdmin):
    list_display = [
        'dia', 'profissional', 'horario'
    ]
    
admin.site.register(Especialidade, EspecialidadeAdmin)
admin.site.register(Profissional, ProfissionalAdmin)
admin.site.register(Agenda, AgendaAdmin)