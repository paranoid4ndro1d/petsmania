from datetime import date
from django.db import models
from django.conf import settings
from django.core.validators import RegexValidator
from django.core.exceptions import ValidationError
from django.db.models.fields.related import ForeignKey

class Especialidade(models.Model):
    nome = models.CharField(verbose_name="Nome", max_length=200)
    
    def __str__(self):
        return f'{self.nome}'
    
class Profissional(models.Model):
    nome = models.CharField(verbose_name="Nome", max_length=200)
    email = models.EmailField(verbose_name="Email")
    phone_regex = RegexValidator(
    regex=r'^\+?1?\d{9,15}$',
    message="O número precisa estar neste formato: \
                    '+99 99 9999-0000'.")

    telefone = models.CharField(verbose_name="Telefone",
                                validators=[phone_regex],
                                max_length=17, null=True, blank=True)
    especialidade = ForeignKey(Especialidade,
                               on_delete=models.CASCADE,
                               related_name='profissionais')
    
    def __str__(self):
        return f'{self.nome}'

def validar_dia(value):
    today = date.today()
    weekday = date.fromisoformat(f'{value}').weekday()

    if value < today:
        raise ValidationError('Não é possivel escolher um data atrasada.')
    if (weekday == 5) or (weekday == 6):
        raise ValidationError('Escolha um dia útil da semana.')

class Agenda(models.Model):
    profissional = ForeignKey(Profissional, on_delete=models.CASCADE, related_name='agenda')
    dia = models.DateField(help_text="Insira uma data para agenda", validators=[validar_dia])
    
    HORARIOS = (
        ("1", "07:00 às 08:00 - Tosadora"),
        ("2", "07:00 às 08:00 - Tosador"),
        ("3", "07:00 às 08:00 - Veterinária"),
        ("4", "07:00 às 08:00 - Banhista"),
        ("5", "07:00 às 08:00 - Banhista"),
        ("6", "07:00 às 08:00 - Cuidadora"),
        ("7", "08:00 às 09:00 - Tosadora"),
        ("8", "08:00 às 09:00 - Tosador"),
        ("9", "08:00 às 09:00 - Veterinária"),
        ("10", "08:00 às 09:00 - Banhista"),
        ("11", "08:00 às 09:00 - Banhista"),
        ("12", "08:00 às 09:00 - Cuidadora"),
        ("13", "09:00 às 10:00 - Tosadora"),
        ("14", "09:00 às 10:00 - Tosador"),
        ("15", "09:00 às 10:00 - Veterinária"),
        ("16", "09:00 às 10:00 - Banhista"),
        ("17", "09:00 às 10:00 - Banhista"),
        ("18", "09:00 às 10:00 - Cuidadora"),
        ("19", "10:00 às 11:00 - Tosadora"),
        ("20", "10:00 às 11:00 - Tosador"),
        ("21", "10:00 às 11:00 - Veterinária"),
        ("22", "10:00 às 11:00 - Banhista"),
        ("23", "10:00 às 11:00 - Banhista"),
        ("24", "10:00 às 11:00 - Cuidadora"),
        ("25", "11:00 às 12:00 - Tosadora"),
        ("26", "11:00 às 12:00 - Tosador"),
        ("27", "11:00 às 12:00 - Veterinária"),
        ("28", "11:00 às 12:00 - Banhista"),
        ("29", "11:00 às 12:00 - Banhista"),
        ("30", "11:00 às 12:00 - Cuidadora"),
        ("31", "12:00 às 13:00 - Tosadora"),
        ("32", "12:00 às 13:00 - Tosador"),
        ("33", "12:00 às 13:00 - Veterinária"),
        ("34", "12:00 às 13:00 - Banhista"),
        ("36", "12:00 às 13:00 - Banhista"),
        ("37", "12:00 às 13:00 - Cuidadora"),
        ("38", "13:00 às 14:00 - Tosadora"),
        ("39", "13:00 às 14:00 - Tosador"),
        ("40", "13:00 às 14:00 - Veterinária"),
        ("41", "13:00 às 14:00 - Banhista"),
        ("42", "13:00 às 14:00 - Banhista"),
        ("43", "13:00 às 14:00 - Cuidadora"),
        ("44", "14:00 às 15:00 - Tosadora"),
        ("45", "14:00 às 15:00 - Tosador"),
        ("46", "14:00 às 15:00 - Veterinária"),
        ("47", "14:00 às 15:00 - Banhista"),
        ("48", "14:00 às 15:00 - Banhista"),
        ("49", "14:00 às 15:00 - Cuidadora"),
    )
    horario = models.CharField(max_length=10, choices=HORARIOS)
    
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, 
        verbose_name='Usuário', 
        on_delete=models.CASCADE
    )
    class Meta:
        unique_together = ('horario', 'dia')
        
    def __str__(self):
        return f'{self.dia.strftime("%b %d %Y")} - {self.get_horario_display()} - {self.profissional}'