from django.urls import path
from . import views

app_name = 'profissionais'

urlpatterns = [
    path('registro/profissional/', views.profissional_cadastro, name='profissional_cadastro'),
    path('registro/especialidade/', views.especialidade_cadastro, name='especialidade_cadastro'),
    path('agendar/', views.agenda_cadastro, name='agendar_serviço'),
    path('agendar/atualizar/<int:pk>/', views.agenda_atualizar, name='agendar_serviço_atualizar'),
    path('agendar/apagar/<int:pk>/', views.agenda_deletar, name='agendar_serviço_deletar'),
    path('minhas/consultas/', views.agenda_lista, name="agenda_lista"),
    path('admin/lista/profissionais/', views.profissional_lista, name="profissionais_lista"),
    path('admin/lista/especialidades/', views.especialidade_lista, name="especialidade_lista"),
    path('listar/profissionais/atualizar/<int:pk>/', views.profissional_atualizar, name='profissional_atualizar'),
    path('listar/profissionais/apagar/<int:pk>/', views.profissional_apagar, name='profissional_deletar'),
    path('listar/especialidades/atualizar/<int:pk>/', views.especialidade_atualizar, name='especialidade_atualizar'),
    path('listar/especialidades/apagar/<int:pk>/', views.especialidade_apagar, name='especialidade_deletar')
    
]