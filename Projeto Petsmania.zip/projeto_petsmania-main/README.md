## Projeto de Clinica para Programação p/ Internet 2

No que consite este projeto:
- Administrar profissionais, usuários, serviços pet e agendas
- Criar uma agenda para disponibilizar os serviços agendados
- Permitir o usuario realizar um agendamento no dia e horario de acordo com agenda do profissional.

Para ter acesso, instale as bibliotecas necessárias para executar o projeto:
```
pip install -r requirements.txt
```
Para poder ter o primeiro acesso e pode configurar o aplicação vamos executar o comando 
'migrate' para gerar o banco de dados padrão do Django(SQLite). E depois criar o superusuario:
```
py ./manage.py migrate
py ./manage.py createsuperuser
Apelido/Usuário: admin
E-mail: admin@mail.com
Password: 
Password (again):
```

Para iniciar o servidor depois deste passo você deve:
```
py ./manage.py runserver
```


Para visualizar se tudo esta executando como esperado vamos acessar o seguinte endereço:
[http://localhost:8000/](http://localhost:8000/)

Ou você pode ter acesso a admin do Django:
[http://localhost:8000/admin](http://localhost:8000/admin)

